package com.example.tdo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
